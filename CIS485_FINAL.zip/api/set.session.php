<?php

    /* Start the session */
    session_start();

    /* to contain ID of page in session */
    $_SESSION['idx'] = $_REQUEST['idx'];
?>