    <head>
        <title><?php $_SESSION['page_name'] ?></title>
        <meta charset="UTF-8">
<!--        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
        <link href="<?php echo $base_URL ?>/commons/css/jquery-ui.css" rel="stylesheet" type="text/css"> 
        <link href="<?php echo $base_URL ?>/commons/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $base_URL ?>/commons/css/style.css" rel="stylesheet" type="text/css">
<!--
        <link href="<?php echo $base_URL ?>/commons/css/fontawesome-all.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $base_URL ?>/commons/css/fa-solid.css" rel="stylesheet" type="text/css">
-->
        <link href="<?php echo $base_URL ?>/commons/css/fa-svg-with-js.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $base_URL ?>/commons/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css"> 
    </head>
