<?php
//    $base_URL = ($_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
    $base_URL = 'http://';
    $base_URL .= $_SERVER['HTTP_HOST'];
    //$base_URL .= "/";
    $base_URL .= "/CIS485_FINAL/";
?>