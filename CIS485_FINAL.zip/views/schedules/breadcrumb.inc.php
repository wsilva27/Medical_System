<div class="offset-2 col-10">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="../../index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="./">Schedules</a></li>
        </ol>
    </nav>
</div>
