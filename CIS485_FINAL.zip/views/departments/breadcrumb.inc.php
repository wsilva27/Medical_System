        <div class="offset-md-2 col-md-10">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="../../index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="./">Departments</a></li>
                </ol>
            </nav>
        </div>
